import 'dart:io';

void main() {
  print("Enter first number:");
  int a = int.parse(stdin.readLineSync()!);

  print("Enter second number:");
  int b = int.parse(stdin.readLineSync()!);

  print('1. Addition');
  print('2. Subtraction');
  print('3. Multiplication');
  print('4. Division');
  print('Enter your choice:');
  
  int ch = int.parse(stdin.readLineSync()!);

  if (ch == 1) {
    addition(a, b);
  } else if (ch == 2) {
    subtraction(a, b);
  } else if (ch == 3) {
    multiplication(a, b);
  } else if (ch == 4) {
    division(a, b);
  } else {
    print("Invalid option");
  }
}

void addition(int a, int b) {
  int c = a + b;
  print("Sum = $c");
}

void subtraction(int a, int b) {
  int c = a - b;
  print("Difference = $c");
}

void multiplication(int a, int b) {
  int c = a * b;
  print("Product = $c");
}

void division(int a, int b) {
  if (b != 0) {
    double c = a / b;
    print("Quotient = $c");
  } else {
    print("Division by zero is not allowed");
  }
}