import 'dart:io';

void main() {
  print("Enter the score for the Written Test (out of 100):");
  double writtenTest = double.parse(stdin.readLineSync()!);

  print("Enter the score for the Lab Exams (out of 100):");
  double labExams = double.parse(stdin.readLineSync()!);

  print("Enter the score for the Assignments (out of 100):");
  double assignments = double.parse(stdin.readLineSync()!);
  double overallGrade = (writtenTest * 70 / 100) +
                        (labExams * 20 / 100) +
                        (assignments * 10 / 100);
  print("The student's overall grade is: ${overallGrade.toStringAsFixed(1)}");
}
