bool isDivisibleByTen(int number) {
  if (number % 10 == 0) {
    return true;
  } else {
    return false;
  }
}
void main() {
  print(isDivisibleByTen(15));  // true
  print(isDivisibleByTen(10));  // false
}
