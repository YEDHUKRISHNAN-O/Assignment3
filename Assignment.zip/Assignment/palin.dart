import 'dart:io';

void main() {
  stdout.write('Enter a string: ');
  String? input = stdin.readLineSync();
  if (input != null) {
    String reversedInput = input.split('').reversed.join('');

    if (input == reversedInput) {
      print('The string "$input" is a palindrome.');
    } else {
      print('The string "$input" is not a palindrome.');
    }
  }
}
